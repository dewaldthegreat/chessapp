
package com.example.chessapp.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BoardScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFEEE8AA)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("ChessApp", fontSize = 32.sp, color = Color.Black)
        Spacer(modifier = Modifier.height(20.dp))
        Box(
            modifier = Modifier
                .size(320.dp)
                .background(Color.White, shape = RoundedCornerShape(4.dp))
        ) {
            // TODO: Add board drawing and interaction
        }
    }
}
